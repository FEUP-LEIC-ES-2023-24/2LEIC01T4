package com.example.get_a_lift

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
